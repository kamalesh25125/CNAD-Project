# UI Upgrade Notes

This revision refreshes the existing Flask/Jinja interface while preserving the current backend routes and API behavior.

## Changes
- Rebranded the interface as PeopleFlow (the application/project functionality remains the same).
- Added a responsive top bar, role-aware sidebar navigation, mobile navigation, user avatar, and workspace status panel.
- Redesigned the login page with a split-panel layout and demo account details.
- Refined cards, tables, buttons, form fields, status badges, QR demo panel, spacing, typography, and responsive behavior.
- Kept the current Flask routes, API calls, in-memory demo data, and health-check endpoints unchanged.

## Run locally
Install dependencies with `pip install -r requirements.txt`, then run `python app.py`.

## Rebuild the container
From the project directory, run `docker build -t employee-attendance-review2:ui-upgrade .`. Load the image into Minikube and update the Deployment only after testing the new UI.

Note: Google Fonts, Bootstrap, and Bootstrap Icons are loaded from CDNs, consistent with the existing Bootstrap CDN approach. The app still works with the system font fallback if Google Fonts cannot load.
